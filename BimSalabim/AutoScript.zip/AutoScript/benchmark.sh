#!/bin/bash

#vps="zvur";
vps="aneka";

if [[ $vps = "zvur" ]]; then
	source="http://scripts.gapaiasa.com"
else
	source="http://d-sshvpspremium.tk/AutoScript"
fi

# go to root
cd

wget $source/bench.sh -O - -o /dev/null|bash
